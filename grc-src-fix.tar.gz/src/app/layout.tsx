import type { Metadata } from 'next';
import './globals.css';
import { PRODUCT_TITLE, PRODUCT_DESCRIPTION } from '@/lib/brand';

export const metadata: Metadata = {
  title: PRODUCT_TITLE,
  description: PRODUCT_DESCRIPTION,
  icons: {
    icon: '/company-logo.png',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
