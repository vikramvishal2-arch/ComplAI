export const PRODUCT_NAME = 'ComplAI';
export const PRODUCT_TAGLINE = 'GRC Compliance Platform';
export const ORGANIZATION_NAME = 'Propel Ready Solutions';

export const PRODUCT_TITLE = `${PRODUCT_NAME} — ${PRODUCT_TAGLINE}`;
export const PRODUCT_DESCRIPTION = `${PRODUCT_NAME} — manage security frameworks and define how your organization complies with each control. Built for ${ORGANIZATION_NAME}.`;
